﻿namespace FR_project.Services
{
    public interface ICommandeService
    {
        List<Models.Commande> GetCommandes();
    }
}