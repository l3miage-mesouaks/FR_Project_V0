﻿using FR_project.Models;

namespace FR_project.Services
{
    public interface IEntrepriseService
    {
        List<Entreprise> GetEntreprises();
    }
}
