﻿namespace FR_project.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string Nom_produit { get; set; }

        public decimal Price { get; set; }

    }
}
